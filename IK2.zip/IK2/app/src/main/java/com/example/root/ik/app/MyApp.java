package com.example.root.ik.app;

import android.app.Application;

import com.example.root.ik.image_slider_service.PicassoImageLoadingService;

import ss.com.bannerslider.ImageLoadingService;
import ss.com.bannerslider.Slider;

public class MyApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        //PicassoImageLoadingService picassoImageLoadingService = new PicassoImageLoadingService(this);
        Slider.init(new PicassoImageLoadingService(this));
    }
}
