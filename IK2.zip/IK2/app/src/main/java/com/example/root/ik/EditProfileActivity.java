package com.example.root.ik;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import androidx.appcompat.app.AlertDialog;
import de.hdodenhof.circleimageview.CircleImageView;

public class EditProfileActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA = 123;
    private static final int PICKFILE_REQUEST_CODE = 12;
    private static final String TAG = "EditProfileActivty";
    ImageView  profileImage;

    TextInputEditText name, email, phone;

    Button saveBtn;

    FirebaseAuth auth;

    FirebaseAuth.AuthStateListener authStateListener;
    DatabaseReference userDatabase;
    StorageReference storageReference;


    Uri imageHoldUri = null;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        profileImage = findViewById(R.id.edtProfileImage);

        name = findViewById(R.id.edtName);

        email = findViewById(R.id.edtEmail);

        phone = findViewById(R.id.edtPhone);

        saveBtn = findViewById(R.id.saveProfileButton);

        progressDialog = new ProgressDialog(this);
        //init firebase
        auth =FirebaseAuth.getInstance();
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                //check user presence
                FirebaseUser user = firebaseAuth.getCurrentUser();

                if (user != null){
                    finish();

                    Intent moveToHome = new Intent(EditProfileActivity.this, HomeActivity.class);
                    moveToHome.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(moveToHome);
                }
            }
        };

        userDatabase = FirebaseDatabase.getInstance().getReference().child("User Profile").child(auth.getCurrentUser().getUid());

        storageReference = FirebaseStorage.getInstance().getReference();
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //select image
                profilePictureSelection();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveUserProfile();

            }
        });


    }

    private void saveUserProfile() {
        final String username, emailS, phoneNumber;

        username = name.getText().toString();

        emailS =  email.getText().toString();

        phoneNumber = phone.getText().toString();

        if (validate()){
            if (imageHoldUri != null){

                progressDialog.setTitle("Saving profile");
                progressDialog.setMessage("please wait...");
                progressDialog.show();


                StorageReference childRef = storageReference.child("User_Profile").child(imageHoldUri.getLastPathSegment());

                String profilePicUrl = imageHoldUri.getLastPathSegment();

//                childRef.putFile(imageHoldUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
//                    @Override
//                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
//                        if (task.isSuccessful()){
//                            userDatabase.child("username").setValue(username);
//
//                            userDatabase.child("email").setValue(emailS);
//
//                            userDatabase.child("phone_number").setValue(phoneNumber);
//
//                            userDatabase.child("userId").setValue(auth.getCurrentUser().getUid());
//                        }
//                    }
//                });

                childRef.putFile(imageHoldUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!urlTask.isSuccessful());
                        //Uri downloadUrl = urlTask.getResult();
                        final  Uri imageUrl = urlTask.getResult();


                        userDatabase.child("username").setValue(username);

                        userDatabase.child("email").setValue(emailS);

                        userDatabase.child("phone_number").setValue(phoneNumber);

                        userDatabase.child("userId").setValue(auth.getCurrentUser().getUid());

                        userDatabase.child("imageUrl").setValue(imageUrl.toString());


                        progressDialog.dismiss();
                    }
                });

            }
            else {
                Toast.makeText(this, "Please select the profile picture", Toast.LENGTH_SHORT).show();
            }
        }else {
            //Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
        }

    }

    public boolean validate() {
        boolean valid = true;

        String mobileN = phone.getText().toString();
        String emailS = email.getText().toString();
        String nameS = name.getText().toString();




        if (mobileN.isEmpty() || mobileN.length() != 11) {
            phone.setError("Please enter valid number");
            valid = false;
        } else {
            phone.setError(null);
        }


        if ( TextUtils.isEmpty(emailS)|| name.length() < 5) {

            email.setError("Please enter title not less than 5 letters");
            valid = false;
        } else {
            email.setError(null);

        }

        if (nameS.isEmpty()) {

            name.setError("Please enter your name");
            valid = false;
        } else {
            name.setError(null);

        }



        return valid;
    }

    private void profilePictureSelection() {

        final CharSequence[] items = {"Take Photos", "Choose from gallery", "Cancel" };


        AlertDialog.Builder builder = new AlertDialog.Builder(EditProfileActivity.this);
        builder.setTitle("Add photos");

        //set items and listeners
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (items[i].equals("Take Photos")){
                    cameraIntent();
                }else if (items[i].equals("Choose from gallery")){
                    galleryIntent();
                }else {
                    dialogInterface.dismiss();
                }
            }
        });
        builder.show();

    }

    private void galleryIntent() {
        Log.d(TAG, "onClick: accessing phone memory");
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICKFILE_REQUEST_CODE);


    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,REQUEST_CAMERA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICKFILE_REQUEST_CODE  && resultCode == RESULT_OK){

            Uri imageUri = data.getData();

            CropImage.activity(imageUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);
        }else if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK){

            Uri imageUri = data.getData();

            CropImage.activity(imageUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);

        }

        //image crop library code
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK){
                imageHoldUri = result.getUri();

                profileImage.setImageURI(imageHoldUri);

            }else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error = result.getError();
            }
        }
    }
}
