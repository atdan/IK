package com.example.root.ik;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.root.ik.common.Common;
import com.example.root.ik.interfaces.OnPhotoSelectedListener;
import com.example.root.ik.model.Item;
import com.example.root.ik.model.User;
import com.example.root.ik.utils.RotateBitmap;
import com.example.root.ik.utils.SelectPhotoDialog;
import com.example.root.ik.utils.UniversalImageLoader;
import com.example.root.ik.utils.Utility;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.rey.material.widget.Spinner;
import com.tangxiaolv.telegramgallery.GalleryActivity;
import com.tangxiaolv.telegramgallery.GalleryConfig;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class PostsActivity extends AppCompatActivity{

    private static final String TAG = "PostsActivity";
    ImageView uploadImage;
    TextInputEditText title, price, name, phoneNumber, description;

    MaterialSpinner categorySpinner;


    SharedPreferences mSettings;
    FirebaseUser user;

    String uid;
    Button submitButton;

    Uri saveUri = null;

    ProgressDialog progressDialog;

    FirebaseDatabase database;
    DatabaseReference categories;
    FirebaseStorage storage;
    StorageReference storageReference;

    Item newItem;

    public static final int PICK_IMAGE_REQUEST = 71;

    public static final int REQUEST_CAMERA = 10;

    public static final int SELECT_FILE = 12;

    private Bitmap mBitmap;
    private byte[] mByteArray;
    private List<String> mPhotos;

    private DatabaseReference mFirebaseDatabase;
    private StorageReference mFirebaseStorage;
    private StorageTask mUploadTask;
    private List<Uri> uploadedImages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts);

        try{
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Upload Advert");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }catch (Exception e){
            Toast.makeText(this, ""+ e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onCreate: "+e.getMessage());
        }

        mFirebaseDatabase = FirebaseDatabase.getInstance().getReference();
        mFirebaseStorage = FirebaseStorage.getInstance().getReference();

        //init Firebase
        database = FirebaseDatabase.getInstance();
        categories = database.getReference("Category");
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        user = FirebaseAuth.getInstance().getCurrentUser();
        uploadImage = findViewById(R.id.add_photo);
        title = findViewById(R.id.title);
        price = findViewById(R.id.price);
        name = findViewById(R.id.name);
        description = findViewById(R.id.description);
        phoneNumber = findViewById(R.id.mobile_number);
        submitButton = findViewById(R.id.submit);

        categorySpinner = findViewById(R.id.categorySpinner);
        categorySpinner.setItems(Common.MOBILE_CATEGORY, Common.FURNITURE_CATEGORY,
                Common.COMPUTER_CATEGORY, Common.VEHICLE_CATEGORY,
                Common.JOBS_CATEGORY, Common.FASHION_CATEGORY);


        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        mSettings = getSharedPreferences(user.getUid(), Context.MODE_PRIVATE);
        String username = mSettings.getString("name", "");
        String mobileNumber = mSettings.getString("mobile", "");
        name.setText(username);
        phoneNumber.setText(mobileNumber);
        if (user != null) {
            String userEmail = user.getEmail();

            uid = user.getUid();


        }
        if (!Utility.isNetworkAvailable(this)) {

            Toast.makeText(this,
                    "Please check internet connection", Toast.LENGTH_SHORT).show();
        }

        init();

    }



    public boolean validate() {
        boolean valid = true;

        String mobileN = phoneNumber.getText().toString();
        String titleS = title.getText().toString();
        String descriptionS = description.getText().toString();
        String nameS = name.getText().toString();
        String priceS = price.getText().toString();




        if (mobileN.isEmpty() || mobileN.length() != 11) {
            phoneNumber.setError("Please enter valid number");
            valid = false;
        } else {
            phoneNumber.setError(null);
        }


        if (titleS.isEmpty() || titleS.length() < 5) {

            title.setError("Please enter title not less than 5 letters");
            valid = false;
        } else {
            title.setError(null);

        }

        if (descriptionS.isEmpty() || descriptionS.length() < 10) {

            description.setError("Please enter description not less than 10 letters");
            valid = false;
        } else {
            description.setError(null);

        }

        if (nameS.isEmpty()) {

            name.setError("Please enter your name");
            valid = false;
        } else {
            name.setError(null);

        }

        if (priceS.isEmpty()) {

            price.setError("Please enter price");
            valid = false;
        } else {
            price.setError(null);

        }


        return valid;
    }



    private void init() {
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadImage();
            }
        });

        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "onClick: Clicked photo");
                chooseImage();
            }
        });
    }




    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Picture"),PICK_IMAGE_REQUEST);
    }

    private void uploadImage() {
        if (saveUri != null){

            if (validate()){
                final ProgressDialog mDialog = new ProgressDialog(this);
                mDialog.setTitle("Please wait");
                mDialog.setMessage("Uploading...");
                mDialog.show();

                String imageName = UUID.randomUUID().toString();
                final StorageReference imageFolder = storageReference.child("images/"+ imageName);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                mDialog.dismiss();
                                Toast.makeText(PostsActivity.this,"Upload successful",Toast.LENGTH_SHORT).show();

                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        //set value for new Category

//                                        Date c = Calendar.getInstance().getTime();
//                                        //System.out.println("Current time => " + c);

                                        //Toast.makeText(PostsActivity.this, "Gotten download url" + uri.toString(), Toast.LENGTH_SHORT).show();
                                        DateFormat dateFormat = DateFormat.getDateTimeInstance();
//                                        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
//                                        String formattedDate = df.format(c);

                                        categories = database.getReference("Category").child(String.valueOf(categorySpinner.getSelectedIndex()));
                                        newItem = new Item(title.toString(), price.toString(),
                                                description.toString(),String.valueOf(categorySpinner.getSelectedIndex()),
                                                name.toString(), phoneNumber.toString(), user.getUid(),
                                                dateFormat.toString(),
                                                uri.toString());

                                        resetFields();
                                        startActivity(new Intent(PostsActivity.this,HomeActivity.class));

                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        mDialog.dismiss();
                        Toast.makeText(PostsActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100* taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                        mDialog.setMessage("Uploading... ");
                    }
                });


                    //Toast.makeText(this, "new item not null", Toast.LENGTH_SHORT).show();
                    categories.child(String.valueOf(categorySpinner.getSelectedIndex())).push().setValue(newItem);
                    Toast.makeText(this, "Your post was uploaded successfully", Toast.LENGTH_SHORT).show();

            }

        }else {
            Toast.makeText(this, "Please select a picture", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){

            saveUri = data.getData();


        }
    }

    private void resetFields() {

        name.setText("");
        description.setText("");
        price.setText("");
        title.setText("");
        phoneNumber.setText("");
    }


    private boolean isEmpty(String s) {
        return s.equals("");
    }



}
