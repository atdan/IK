package com.example.root.ik.model;

public class Category {
    private String Name, Price;
    private String Image;

    public Category(){

    }

    public Category(String name, String price, String image) {
        Name = name;
        Price = price;
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return Image;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public void setImage(String image) {
        Image = image;
    }
}
